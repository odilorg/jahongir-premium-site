<?php
$title = "What our guests say about Jahongir Premium hotel";
include("includes/header.php") ?>
        
        <!-- SUB BANNER -->
        <section class="section-sub-banner bg-15">
            <div class="awe-overlay"></div>
            <div class="sub-banner">
                <div class="container">
                    <div class="text text-center">
                        <h2>GUEST BOOK</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- END / SUB BANNER -->
        
        <!-- GUEST BOOK -->
        <section class="section-guest-book">
            <div class="container">
                <div class="guest-book">
                    
                    <!-- GUEST BOOK HEAD -->
                    <div class="guest-book_head bg-8">
                        <div class="text">
                            <h2>READ OUR GUEST BOOK FORM CUSTOMER</h2>
                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal .</p>
                            <a href="ajax/ajax-guest-book-form.html" class="awe-btn awe-btn-13 awe-ajax">WRITE IN GUEST BOOK</a>
                        </div>
                    </div>
                    <!-- END / GUEST BOOK HEAD -->
                    
                    <!-- GUEST BOOK MASONRY -->
                    <div class="guest-book_content">

                        <div class="row">
                            <div class="guest-book_mansory">

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>BEST PRICE</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>GOOD SERVICE</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>Love the hotel</h2>
                                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>I LIKE YOUR HOTTEL</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>Love the hotel</h2>
                                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>GOOD SERVICE</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>BEST PRICE</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>I WILL COME BACK</h2>
                                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock</p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                                <!-- ITEM -->
                                <div class="item-masonry col-xs-6 col-md-4">
                                    <div class="guest-book_item ">
                                        <span class="icon lotus-icon-quote-left"></span>
                                        <h2>BEST PRICE</h2>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. </p>
                                        <span><b>Jonatha Owens</b> - Sydney Australia</span>
                                    </div>
                                </div>
                                <!-- END / ITEM -->

                            </div>
                        </div>

                        <!-- PAGE NAVIGATION   -->
                        <ul class="page-navigation text-center">
                            <li class="first"><a href="#"><i class="fa fa-arrow-left"></i></a></li>
                            <li><a href="#">1</a></li>
                            <li class="current-page"><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#">6</a></li>
                            <li class="last"><a href="#"><i class="fa fa-arrow-right"></i></a></li>
                        </ul>
                        <!-- END / PAGE NAVIGATION   -->

                    </div>
                    <!-- END / GUEST BOOK MASONRY -->
                </div>
            </div>
        </section>
        <!-- END / GUEST BOOK -->
<?php include("includes/footer.php") ?>
</body>
</html>